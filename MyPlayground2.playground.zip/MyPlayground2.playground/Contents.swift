//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


print("hhh")


for i in -20...20
{
    i*i*i;
}



