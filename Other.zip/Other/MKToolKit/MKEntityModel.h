//
//  MKEntityModel.h
//  Pure-Weibo
//
//  Created by Mark Lewis on 16-8-16.
//  Copyright (c) 2016年 MarkLewis. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MKEntityModel : NSObject

@property (nonatomic, strong) NSString *tableName; //note
@property (nonatomic, strong) NSArray *attributesName; //note


@end
