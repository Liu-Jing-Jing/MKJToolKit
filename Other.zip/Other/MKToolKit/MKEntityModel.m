//
//  MKEntityModel.m
//  Pure-Weibo
//
//  Created by Mark Lewis on 16-8-16.
//  Copyright (c) 2016年 MarkLewis. All rights reserved.
//

#import "MKEntityModel.h"

@implementation MKEntityModel

@end
