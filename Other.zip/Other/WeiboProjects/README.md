# There are Sina Weibo Projects
- Development in Xcode 5.1.1
- Use the ARC and MRC management memory
- Using AN Framework wrapping Networking request
