//
//  BaseNavigationController.h
//  WXWeibo
//
//  Created by Mark Lewis on 16-2-3.
//  Copyright (c) 2016年 TechLewis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseNavigationController : UINavigationController

@end
