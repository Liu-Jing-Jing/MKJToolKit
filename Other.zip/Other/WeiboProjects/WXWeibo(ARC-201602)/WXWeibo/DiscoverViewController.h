//
//  DiscoverViewController.h
//  WXWeibo
//
//  Created by Mark Lewis on 16-2-3.
//  Copyright (c) 2016年 TechLewis. All rights reserved.
//

#import "BaseViewController.h"

@interface DiscoverViewController : BaseViewController

@end
