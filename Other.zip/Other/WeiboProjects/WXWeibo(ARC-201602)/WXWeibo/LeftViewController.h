//
//  LeftViewController.h
//  WXWeibo
//
//  Created by Mark Lewis on 16-2-4.
//  Copyright (c) 2016年 TechLewis. All rights reserved.
//

#import "BaseViewController.h"

@interface LeftViewController : BaseViewController

@end
