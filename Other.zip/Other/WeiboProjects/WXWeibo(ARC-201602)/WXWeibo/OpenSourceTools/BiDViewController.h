//
//  BiDViewController.h
//  WeiboCell
//
//  Created by Mark Lewis on 15-2-28.
//  Copyright (c) 2015年 TechLewis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BiDViewController : UITableViewController

@end
