//
//  BaseNavigationController.h
//  WXWeibo
//


#import <UIKit/UIKit.h>

@interface BaseNavigationController : UINavigationController

@end
