//
//  UserModel.m
//  WXWeibo
//

#import "UserModel.h"

@implementation UserModel

@synthesize description = _description;
@end
