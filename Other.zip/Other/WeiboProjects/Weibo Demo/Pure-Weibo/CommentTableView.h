//
//  CommentTableView.h
//  WXWeibo

#import "BaseTableView.h"
@interface CommentTableView : BaseTableView
@property (nonatomic, retain) UIView *headerView;
@property (nonatomic, retain) NSDictionary *commentDic;

@end
