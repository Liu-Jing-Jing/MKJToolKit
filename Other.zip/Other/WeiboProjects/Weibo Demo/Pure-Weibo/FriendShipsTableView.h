//
//  FriendShipsTableView.h
//  WXWeibo
//
//  Created by Mark Lewis on 16-6-3.
//  Copyright (c) 2016年 Mark Lewis. All rights reserved.
//

#import "BaseTableView.h"
#import "FriendshipsCell.h"

@interface FriendShipsTableView : BaseTableView

@end
