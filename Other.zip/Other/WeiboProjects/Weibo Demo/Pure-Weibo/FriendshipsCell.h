//
//  FriendshipsCell.h
//  WXWeibo
//
//  Created by Mark Lewis on 16-6-3.
//  Copyright (c) 2016年 Mark Lewis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FriendshipsCell : UITableViewCell

@property(nonatomic,retain)NSArray *data;//3个user对象
@end
