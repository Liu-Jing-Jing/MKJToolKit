//
//  LeftViewController.h
//  WXWeibo


#import "BaseViewController.h"

@interface LeftViewController : BaseViewController

@end
