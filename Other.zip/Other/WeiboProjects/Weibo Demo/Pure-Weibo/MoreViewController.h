//
//  MoreViewController.h
//  WXWeibo
//  更多控制器

#import "BaseViewController.h"

@interface MoreViewController : BaseViewController

@end
