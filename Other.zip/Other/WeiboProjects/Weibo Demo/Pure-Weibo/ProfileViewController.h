//
//  ProfileViewController.h
//  WXWeibo
//  个人中心控制器

#import "BaseViewController.h"

@interface ProfileViewController : BaseViewController

@property (retain, nonatomic) IBOutlet UITableView *tableView;
@end
