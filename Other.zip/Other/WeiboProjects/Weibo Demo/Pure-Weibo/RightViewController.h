//
//  RightViewController.h
//  WXWeibo


#import "BaseViewController.h"

@interface RightViewController : BaseViewController

- (IBAction)sendAction:(id)sender;
@end
