//
//  SendViewController.h
//  Pure-Weibo
//
//  Created by Mark Lewis on 16-5-8.
//  Copyright (c) 2016年 MarkLewis. All rights reserved.
//

#import "BaseViewController.h"
#import "MKFaceView.h"
@interface SendViewController : BaseViewController<UIScrollViewDelegate>

// send data
@property (nonatomic, strong) NSString *longitude;
@property (nonatomic, strong) NSString *latitude;
@property (nonatomic, strong) UIImage *sendImage;
@property (nonatomic, strong) UIButton *sendImageButton;
@property (nonatomic, strong) NSMutableArray *buttons;

@property (nonatomic, strong) IBOutlet UITextView *textVIew;
@property (nonatomic, strong) IBOutlet UIView *editorToolbar;
@property (nonatomic, strong) IBOutlet UIImageView *placeBackgrougView;
@property (nonatomic, strong) IBOutlet UILabel *placeLabel;
@property (nonatomic, strong) IBOutlet UIView *placeView;
@end
