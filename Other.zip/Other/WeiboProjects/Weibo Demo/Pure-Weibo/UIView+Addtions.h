//
//  UIView+Addtions.h
//  WXWeibo

#import <UIKit/UIKit.h>

@interface UIView (Addtions)

- (UIViewController *)viewController;
@end
