//
//  UserInfoDataModel.h
//  Pure-Weibo
//
//  Created by Mark Lewis on 16-8-23.
//  Copyright (c) 2016年 MarkLewis. All rights reserved.
//

#import "MKBaseModel.h"

@interface UserInfoDataModel : MKBaseModel

@property (nonatomic, strong) NSNumber *weiboId;         //微博id
@property (nonatomic, strong) NSNumber *followers_count; //粉丝数
@property (nonatomic, strong) NSNumber *friends_count;   //关注数
@property (nonatomic, strong) NSNumber *statuses_count;  //微博数

@end
