//
//  UserInfoDataModel.m
//  Pure-Weibo
//
//  Created by Mark Lewis on 16-8-23.
//  Copyright (c) 2016年 MarkLewis. All rights reserved.
//

#import "UserInfoDataModel.h"

@implementation UserInfoDataModel

@end
