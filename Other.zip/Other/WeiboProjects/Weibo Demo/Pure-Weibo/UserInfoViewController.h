//
//  UserInfoViewController.h
//  WXWeibo

#import "BaseViewController.h"

@interface UserInfoViewController : BaseViewController

@end
