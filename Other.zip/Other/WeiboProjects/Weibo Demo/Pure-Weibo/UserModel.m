//
//  UserModel.m
//  Shutterbug
//
//  Created by Mark Lewis on 16-8-12.
//  Copyright (c) 2016年 MarkLewis. All rights reserved.
//

#import "UserModel.h"
#import "SDWebImage/UIImageView+WebCache.h"

@implementation UserModel
@synthesize description = _description;


+ (NSArray *)parseResponsDataAsUserModels:(id)responsData
{
    NSArray *users = [responsData objectForKey:@"users"];
    NSMutableArray *usersList = [NSMutableArray array];
    for (NSDictionary *userDic in users)
    {
        UserModel *user = [[UserModel alloc] initWithDataDic:userDic];
        [usersList addObject:user];
        // UIImageView *imageView = [[UIImageView alloc] init];
        //[imageView setImageWithURL:[NSURL URLWithString:user.profile_image_url]];
    }
    
    return usersList;
}
@end
