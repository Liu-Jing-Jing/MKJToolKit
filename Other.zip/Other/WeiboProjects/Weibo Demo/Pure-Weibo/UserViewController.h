//
//  UserViewController.h
//  WXWeibo

#import "BaseViewController.h"
#import "WeiboTableView.h"
#import "UserModel.h"
@interface UserViewController : BaseViewController

@property (nonatomic, strong) IBOutlet WeiboTableView *tableView;
@property (nonatomic, strong) NSString *userName;
@property (nonatomic, strong) NSString *userId;
@end
