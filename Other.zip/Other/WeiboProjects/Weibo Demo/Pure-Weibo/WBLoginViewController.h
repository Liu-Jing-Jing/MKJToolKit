//
//  WBLoginViewController.h
//  Pure-Weibo
//
//  Created by Mark Lewis on 16-8-24.
//  Copyright (c) 2016年 MarkLewis. All rights reserved.
//

#import <UIKit/UIKit.h>
#define kNavWithStatusBarHeight (self.navigationController.navigationBar.height + [[UIApplication sharedApplication] statusBarFrame].size.height)

@interface WBLoginViewController : UIViewController<UIWebViewDelegate>

@end

