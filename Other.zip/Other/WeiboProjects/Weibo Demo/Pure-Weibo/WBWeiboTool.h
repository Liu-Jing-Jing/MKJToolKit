//
//  WBWeiboTool.h
//  Weibo Demo
//
//  Created by Mark Lewis on 16-8-22.
//  Copyright (c) 2016年 MarkLewis. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WBWeiboTool : NSObject
// 选择根控制器
+ (void)chooseRootViewController;

+ (NSString *) URLAppendingAccessTokenWithQueryPath:(NSString *)urlStr;
@end
