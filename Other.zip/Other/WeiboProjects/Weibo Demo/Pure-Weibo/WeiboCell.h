//
//  WeiboCell.h
//  WXWeibo
//  自定义微博cell

#import <UIKit/UIKit.h>

@class WeiboModel;
@class WeiboView;
@class MKImageView;

@interface WeiboCell : UITableViewCell

//微博数据模型对象
@property(nonatomic,retain)WeiboModel *weiboModel;
//微博视图
@property(nonatomic,retain)WeiboView *weiboView;
@end
