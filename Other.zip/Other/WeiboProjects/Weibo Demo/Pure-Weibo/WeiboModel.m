//
//  WeiboModel.m
//  Shutterbug
//
//  Created by Mark Lewis on 16-8-12.
//  Copyright (c) 2016年 MarkLewis. All rights reserved.
//


#import "WeiboModel.h"
#import "UserModel.h"

@implementation WeiboModel
+ (NSArray *)parseResponsDataAsWeiboModels:(id)responsData
{
    NSArray *statues = [responsData objectForKey:@"statuses"];
    NSMutableArray *weibos = [NSMutableArray arrayWithCapacity:statues.count];
    for (NSDictionary *statuesDic in statues)
    {
        WeiboModel *weibo = [[WeiboModel alloc] initWithDataDic:statuesDic];
        [weibos addObject:weibo];
    }
    
    return [weibos copy];
}

- (NSDictionary *)attributeMapDictionary
{
    NSDictionary *mapAtt = @{
        @"createDate":@"created_at",
        @"weiboId":@"id",
        @"text":@"text",
        @"source":@"source",
        @"favorited":@"favorited",
        @"thumbnailImage":@"thumbnail_pic",
        @"bmiddleImage":@"bmiddle_pic",
        @"originalImage":@"original_pic",
        @"geo":@"geo",
        @"repostsCount":@"reposts_count",
        @"commentsCount":@"comments_count"
    };
    
    return mapAtt;
}

- (void)setAttributes:(NSDictionary *)dataDic
{
    //将字典数据根据映射关系填充到当前对象的属性上。
    [super setAttributes:dataDic];
    
    
    NSDictionary *retweetDic = [dataDic objectForKey:@"retweeted_status"];
    if (retweetDic != nil)
    {
        WeiboModel *relWeibo = [[WeiboModel alloc] initWithDataDic:retweetDic];
        self.relWeibo = relWeibo;
    }
    
    NSDictionary *userDic = [dataDic objectForKey:@"user"];
    if (userDic != nil)
    {
        UserModel *user = [[UserModel alloc] initWithDataDic:userDic];
        self.user = user;
    }
}


@end
