//
//  WeiboTableView.h
//  WXWeibo


#import "BaseTableView.h"

@interface WeiboTableView : BaseTableView<UITableViewDelegate>

@end
