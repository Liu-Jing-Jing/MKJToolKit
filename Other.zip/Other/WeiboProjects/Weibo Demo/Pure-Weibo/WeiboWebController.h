//
//  WeiboWebController.h
//  WXWeibo

#import <UIKit/UIKit.h>

@interface WeiboWebController : UIViewController
@property (retain, nonatomic) UIWebView *webView;
@property (copy,   nonatomic) NSURL *urlString;
@end
