//
//  WeiboWebController.m
//  WXWeibo

#import "WeiboWebController.h"

@interface WeiboWebController ()

@end

@implementation WeiboWebController

- (void)setUrlString:(NSURL *)urlString
{
    if (_urlString != urlString)
    {
        // [_urlString release];
        // _urlString = [urlString retain];
        _urlString = urlString;
    }
    
    NSURLRequest *request = [NSURLRequest requestWithURL:self.urlString];
    [self.webView loadRequest:request];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.webView = [[UIWebView alloc] init];
    self.webView.frame = self.view.bounds;
    self.webView.frame = CGRectMake(0, 0, 320, 500);
    [self.view addSubview:_webView];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
